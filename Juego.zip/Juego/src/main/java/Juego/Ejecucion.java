package Juego;

import java.util.Scanner;


public class Ejecucion 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Procedimiento pro = new Procedimiento();

        System.out.println("PIEDRA PAPEL O TIJERA");
        System.out.println("Seleccione 1=Piedra, 2=Papel, 3=Tijera: ");
        pro.setPersona(sc.nextInt());
        pro.Resultado();

        sc.close();
    }
}

