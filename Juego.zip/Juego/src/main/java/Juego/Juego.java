package Juego;

public abstract class Juego 
{
    public abstract String Resultado();
}
