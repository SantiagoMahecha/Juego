package Juego;
import java.util.Scanner;
 
public class Procedimiento
{
        Scanner sc = new Scanner(System.in);

        private int Persona;
        private int Computadora;

        public Procedimiento()
        {
    
        }


        public Procedimiento(int Persona, int Computadora) {
            this.Persona = Persona;
            this.Computadora = Computadora;
        }


        public int getPersona() {
            return Persona;
        }

        public void setPersona(int persona) {
            Persona = persona;
        }

        public int getComputadora() {
            return Computadora;
        }

        public void setComputadora(int computadora) {
            Computadora = computadora;
        }


        public String Resultado()
        {
        setComputadora((int)(Math.random() * 3) + 1);
        System.out.print("La computadora habia escogido: ");
        switch ( getComputadora() )
        {
            case 1:
                System.out.println("Piedra");
                switch (getPersona())
                {
                   case 1: System.out.println("Empate"); 
                   break;
                   case 2: System.out.println("Gano"); 
                   break;
                   case 3: System.out.println("Computadora Gana"); 
                   break;
                }
                break;
 
            case 2:
                System.out.println("Papel");
                switch ( getPersona() )
                {
                   case 1: System.out.println("Computadora Gana"); 
                   break;
                   case 2: System.out.println("Empate"); 
                   break;
                   case 3: System.out.println("Gano"); 
                   break;
                }
                break;
 
            case 3:
                System.out.println("Tijera");
                switch ( getPersona() )
                {
                   case 1: System.out.println("Gano"); 
                   break;
                   case 2: System.out.println("Computadora Gana"); 
                   break;
                   case 3: System.out.println("Empate"); 
                   break;
                }
                break;
        }
        sc.close();
        return null;
    }
}
    



